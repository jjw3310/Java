public class ConcertApp {
	
	public static void main (String[] args) {
		Concert concert = new Concert("��ǰ�ܼ�ƮȦ");
		concert.run();
	}
}
